#include <stdio.h>

int main() {
    int idade;

    printf("Digite sua idade: ");
    scanf("%d", &idade);

    if (idade >= 18) {
        printf("Você está apto a votar.\n");
    } else {
        printf("Você não está apto a votar. A idade mínima para votar é 18 anos.\n");
    }

    return 0;
}