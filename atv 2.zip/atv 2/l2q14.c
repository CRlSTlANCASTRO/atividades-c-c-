#include <stdio.h>

int main() {
    int num;

    printf("Digite um número inteiro: ");
    scanf("%d", &num);

    if (num % 2 == 0 && num % 3 == 0 && num % 5 == 0) {
        printf("O número é divisível por 2, 3 e 5.\n");
    } else {
        printf("O número não é divisível por 2, 3 e 5 simultaneamente.\n");
    }

    return 0;
}