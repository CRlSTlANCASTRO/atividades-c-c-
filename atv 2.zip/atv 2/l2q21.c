#include <stdio.h>

int main() {
    int tipoProduto, quantidade;
    float precoBase, precoTotal, desconto;

    printf("Digite o código do tipo de produto (1-5): ");
    scanf("%d", &tipoProduto);

    printf("Digite a quantidade de unidades compradas: ");
    scanf("%d", &quantidade);

    switch (tipoProduto) {
        case 1:
            precoBase = 150.0;
            break;
        case 2:
            precoBase = 50.0;
            break;
        case 3:
            precoBase = 80.0;
            break;
        case 4:
            precoBase = 120.0;
            break;
        case 5:
            precoBase = 90.0;
            break;
        default:
            printf("Código de produto inválido!\n");
            return 1;
    }

    precoTotal = precoBase * quantidade;

    if (quantidade >= 1 && quantidade <= 5) {
        desconto = precoTotal * 0.05;
    } else if (quantidade >= 6 && quantidade <= 10) {
        desconto = precoTotal * 0.10;
    } else if (quantidade > 10) {
        desconto = precoTotal * 0.15;
    } else {
        printf("Quantidade inválida!\n");
        return 1;
    }

    precoTotal -= desconto;

    printf("Preço total com desconto: R$ %.2f\n", precoTotal);

    return 0;
}