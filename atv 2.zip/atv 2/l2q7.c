#include <stdio.h>

int main() {
    int nivelAgua;

    printf("Digite o nível de água no tanque (0-100): ");
    scanf("%d", &nivelAgua);

    if (nivelAgua < 0 || nivelAgua > 100) {
        printf("Nível de água inválido. Deve estar entre 0 e 100.\n");
    } else if (nivelAgua < 30) {
        printf("Nível de água: Baixo\n");
    } else if (nivelAgua < 70) {
        printf("Nível de água: Médio\n");
    } else {
        printf("Nível de água: Alto\n");
    }

    return 0;
}