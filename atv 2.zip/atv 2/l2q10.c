#include <stdio.h>

int main() {
    float velocidade;

    printf("Digite a velocidade do veículo (km/h): ");
    scanf("%f", &velocidade);

    if (velocidade < 0) {
        printf("Velocidade inválida. Deve ser maior ou igual a 0.\n");
    } else if (velocidade < 30) {
        printf("Velocidade: Baixa\n");
    } else if (velocidade <= 60) {
        printf("Velocidade: Média\n");
    } else {
        printf("Velocidade: Alta\n");
    }

    return 0;
}