#include <stdio.h>

int main() {
    int a, b, c;

    printf("Digite os três lados do triângulo (inteiro): ");
    scanf("%d %d %d", &a, &b, &c);

    if (a <= 0 || b <= 0 || c <= 0) {
        printf("Lados inválidos. Deve ser maior que 0.\n");
    } else if (a + b <= c || a + c <= b || b + c <= a) {
        printf("Não forma um triângulo.\n");
    } else {
        if (a == b && b == c) {
            printf("Triângulo Equilátero\n");
        } else if (a == b || b == c || a == c) {
            printf("Triângulo Isósceles\n");
        } else {
            printf("Triângulo Escaleno\n");
        }
    }

    return 0;
}