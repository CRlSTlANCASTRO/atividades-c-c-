#include <stdio.h>

int main() {
    int num, resto10, resto100, resto1000, distancia10, distancia100, distancia1000;

    printf("Digite um número inteiro: ");
    scanf("%d", &num);

    resto10 = num % 10;
    resto100 = num % 100;
    resto1000 = num % 1000;

    distancia10 = (resto10 > 5) ? 10 - resto10 : resto10;
    distancia100 = (resto100 > 50) ? 100 - resto100 : resto100;
    distancia1000 = (resto1000 > 500) ? 1000 - resto1000 : resto1000;

    if (distancia10 <= distancia100 && distancia10 <= distancia1000) {
        printf("O número está mais próximo de 10\n");
    } else if (distancia100 <= distancia10 && distancia100 <= distancia1000) {
        printf("O número está mais próximo de 100\n");
    } else {
        printf("O número está mais próximo de 1000\n");
    }

    return 0;
}