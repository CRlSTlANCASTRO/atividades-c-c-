#include <stdio.h>

int main() {
    int tipoEvento, capacidadeMaxima, assentosDisponiveis, quantidadeAssentos;
    char mensagem[50];

    printf("Selecione um tipo de evento:\n");
    printf("1 - Concerto\n");
    printf("2 - Teatro\n");
    printf("3 - Evento Esportivo\n");
    printf("4 - Conferência\n");
    scanf("%d", &tipoEvento);

    switch (tipoEvento) {
        case 1:
            capacidadeMaxima = 500;
            assentosDisponiveis = 500;
            break;
        case 2:
            capacidadeMaxima = 200;
            assentosDisponiveis = 200;
            break;
        case 3:
            capacidadeMaxima = 1000;
            assentosDisponiveis = 1000;
            break;
        case 4:
            capacidadeMaxima = 300;
            assentosDisponiveis = 300;
            break;
        default:
            printf("Tipo de evento inválido!\n");
            return 1;
    }

    printf("Quantos assentos deseja reservar? ");
    scanf("%d", &quantidadeAssentos);

    if (quantidadeAssentos <= assentosDisponiveis) {
        assentosDisponiveis -= quantidadeAssentos;
        sprintf(mensagem, "Reserva confirmada! %d assentos reservados.", quantidadeAssentos);
    } else {
        sprintf(mensagem, "Não há assentos suficientes disponíveis. Solicitação não atendida.");
    }

    printf("%s\n", mensagem);
    printf("Assentos disponíveis: %d\n", assentosDisponiveis);

    return 0;
} 