#include <stdio.h>
#include <string.h>

int main() {
    char clima[10];
    float temperatura;
    char atividade[50];

    printf("Digite o tipo de clima (ensolarado, nublado ou chuvoso): ");
    scanf("%s", clima);

    printf("Digite a temperatura atual em graus Celsius: ");
    scanf("%f", &temperatura);

    if (strcmp(clima, "ensolarado") == 0) {
        if (temperatura > 25) {
            strcpy(atividade, "Ir à praia ou fazer um piquenique");
        } else if (temperatura >= 15 && temperatura <= 25) {
            strcpy(atividade, "Caminhadas ou passeios de bicicleta");
        } else if (temperatura < 15) {
            strcpy(atividade, "Fotografia da natureza ou observação de pássaros");
        }
    } else if (strcmp(clima, "nublado") == 0) {
        if (temperatura > 20) {
            strcpy(atividade, "Visitar museus ou fazer compras em centros comerciais ao ar livre");
        } else if (temperatura >= 10 && temperatura <= 20) {
            strcpy(atividade, "Passeios culturais, como galerias de arte ou teatros");
        } else if (temperatura < 10) {
            strcpy(atividade, "Leitura em bibliotecas ou sessões de cinema");
        }
    } else if (strcmp(clima, "chuvoso") == 0) {
        if (temperatura > 15) {
            strcpy(atividade, "Visitar um spa ou fazer aulas de culinária");
        } else if (temperatura >= 5 && temperatura <= 15) {
            strcpy(atividade, "Museus de ciência ou sessões de boliche");
        } else if (temperatura < 5) {
            strcpy(atividade, "Uma tarde de jogos de tabuleiro em casa ou uma maratona de filmes");
        }
    } else {
        printf("Clima inválido!\n");
        return 1;
    }

    printf("Atividade sugerida: %s\n", atividade);

    return 0;
}