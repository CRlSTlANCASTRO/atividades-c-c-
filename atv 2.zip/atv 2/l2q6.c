#include <stdio.h>

int main() {
    int numero;

    printf("Digite um número: ");
    scanf("%d", &numero);

    if (numero >= 1 && numero <= 100) {
        printf("O número %d está entre 1 e 100, inclusive.\n", numero);
    } else {
        printf("O número %d não está entre 1 e 100, inclusive.\n", numero);
    }

    return 0;
}