#include <stdio.h>

int main() {
    int horario, trafego;
    int tempoVerde, tempoAmarelo, tempoVermelho;

    printf("Digite o horário do dia (1 = manhã, 2 = tarde, 3 = noite): ");
    scanf("%d", &horario);

    printf("Digite o nível de tráfego (1 = baixo, 2 = médio, 3 = alto): ");
    scanf("%d", &trafego);

    switch (horario) {
        case 1: // manhã
            tempoVerde = 30;
            tempoAmarelo = 5;
            tempoVermelho = 20;
            break;
        case 2: // tarde
            tempoVerde = 25;
            tempoAmarelo = 5;
            tempoVermelho = 25;
            break;
        case 3: // noite
            tempoVerde = 20;
            tempoAmarelo = 5;
            tempoVermelho = 30;
            break;
        default:
            printf("Horário inválido!\n");
            return 1;
    }

    if (trafego == 1) { // tráfego baixo
        tempoVerde -= 5;
        tempoVermelho += 5;
    } else if (trafego == 3) { // tráfego alto
        tempoVerde += 5;
        tempoVermelho -= 5;
    }

    printf("Tempo de luz verde: %d segundos\n", tempoVerde);
    printf("Tempo de luz amarela: %d segundos\n", tempoAmarelo);
    printf("Tempo de luz vermelha: %d segundos\n", tempoVermelho);

    return 0;
}