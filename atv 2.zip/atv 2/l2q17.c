#include <stdio.h>

int main() {
    float valorInicial, desconto, valorFinal;

    printf("Digite o valor inicial da compra: R$ ");
    scanf("%f", &valorInicial);

    if (valorInicial <= 100) {
        desconto = valorInicial * 0.05;
    } else if (valorInicial <= 500) {
        desconto = valorInicial * 0.10;
    } else {
        desconto = valorInicial * 0.15;
    }

    valorFinal = valorInicial - desconto;

    printf("Valor final da compra: R$ %.2f\n", valorFinal);

    return 0;
}