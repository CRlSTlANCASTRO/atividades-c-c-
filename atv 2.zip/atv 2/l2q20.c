#include <stdio.h>

int main() {
    int horas, custoTotal;

    printf("Digite o número total de horas que o carro ficou estacionado: ");
    scanf("%d", &horas);

    if (horas <= 2) {
        custoTotal = horas * 5;
    } else if (horas <= 5) {
        custoTotal = 2 * 5 + (horas - 2) * 3;
    } else {
        custoTotal = 2 * 5 + 3 * 3 + (horas - 5) * 2;
    }

    printf("O custo total é de R$ %d,00\n", custoTotal);

    return 0;
}