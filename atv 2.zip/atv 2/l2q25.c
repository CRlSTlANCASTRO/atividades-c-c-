#include <stdio.h>

int main() {
    float rendimentoAnual, impostoDevido;
    int faixaImposto;

    printf("Digite seu rendimento anual: R$ ");
    scanf("%f", &rendimentoAnual);

    if (rendimentoAnual <= 22000.00) {
        faixaImposto = 1; // 5%
    } else if (rendimentoAnual > 22000.00 && rendimentoAnual <= 45000.00) {
        faixaImposto = 2; // 15%
    } else {
        faixaImposto = 3; // 25%
    }

    switch (faixaImposto) {
        case 1:
            impostoDevido = rendimentoAnual * 0.05;
            break;
        case 2:
            impostoDevido = rendimentoAnual * 0.15;
            break;
        case 3:
            impostoDevido = rendimentoAnual * 0.25;
            break;
        default:
            printf("Erro ao calcular imposto!\n");
            return 1;
    }

    printf("O imposto devido é de R$ %.2f\n", impostoDevido);

    return 0;
}