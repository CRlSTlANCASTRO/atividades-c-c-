#include <stdio.h>

int main() {
    int nota;

    printf("Digite a nota do estudante (0-100): ");
    scanf("%d", &nota);

    if (nota < 0 || nota > 100) {
        printf("Nota inválida. Deve estar entre 0 e 100.\n");
    } else if (nota >= 80) {
        printf("Nota: Excelente\n");
    } else if (nota >= 60) {
        printf("Nota: Bom\n");
    } else if (nota >= 40) {
        printf("Nota: Suficiente\n");
    } else {
        printf("Nota: Insuficiente\n");
    }

    return 0;
}